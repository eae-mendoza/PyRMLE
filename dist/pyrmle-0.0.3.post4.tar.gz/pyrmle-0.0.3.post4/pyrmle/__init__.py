# __init__.py

from pyrmle.pyrmle import *

# Version of the PyRMLE package
__version__ = "1.0.0"
