# __init__.py

# Version of the PyRMLE package
__version__ = "1.0.0"
